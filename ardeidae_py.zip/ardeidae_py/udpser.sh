#! /bin/sh

python3 ardeidae/udpser.py