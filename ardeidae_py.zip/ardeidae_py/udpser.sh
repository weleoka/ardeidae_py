#! /bin/sh

python3 udpser.py