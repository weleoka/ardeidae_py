#! /bin/sh

python3 tcpser.py