#! /bin/sh

python3 ardeidae/tcpser.py