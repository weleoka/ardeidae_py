#! /bin/sh

python3 tcpcli.py