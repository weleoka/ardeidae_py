#! /bin/sh

python3 ardeidae/tcpcli.py $@