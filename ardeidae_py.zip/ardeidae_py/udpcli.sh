#! /bin/sh

python3 udpcli.py