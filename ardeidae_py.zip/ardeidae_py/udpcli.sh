#! /bin/sh

python3 ardeidae/udpcli.py